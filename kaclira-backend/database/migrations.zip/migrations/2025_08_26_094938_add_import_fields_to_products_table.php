<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Add SKU field first
            $table->string('sku')->unique()->nullable()->after('barcode');
            
            // Add import-related fields
            $table->string('gtin')->nullable()->after('sku');
            $table->string('mpn')->nullable()->after('gtin');
            $table->decimal('price', 10, 2)->nullable()->after('model');
            $table->decimal('sale_price', 10, 2)->nullable()->after('price');
            $table->string('availability')->default('in_stock')->after('admin_approved');
            $table->string('condition')->default('new')->after('availability');
            $table->string('image_url')->nullable()->after('images');
            $table->json('additional_images')->nullable()->after('image_url');
            $table->string('external_url')->nullable()->after('additional_images');
            $table->decimal('weight', 8, 2)->nullable()->after('external_url');
            $table->string('google_category')->nullable()->after('weight');
            $table->string('import_source')->nullable()->after('google_category');
            $table->timestamp('imported_at')->nullable()->after('import_source');
            $table->unsignedBigInteger('seller_id')->nullable()->after('created_by');
            $table->boolean('is_active')->default(true)->after('seller_id');
            $table->string('slug')->nullable()->after('name');
            
            // Add foreign key for seller
            $table->foreign('seller_id')->references('id')->on('users')->onDelete('cascade');
            
            // Add indexes
            $table->index('sku');
            $table->index('gtin');
            $table->index('seller_id');
            $table->index('is_active');
            $table->index('availability');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Drop foreign keys first
            $table->dropForeign(['seller_id']);
            
            // Drop all added columns
            $table->dropColumn([
                'sku',
                'gtin',
                'mpn',
                'price',
                'sale_price',
                'availability',
                'condition',
                'image_url',
                'additional_images',
                'external_url',
                'weight',
                'google_category',
                'import_source',
                'imported_at',
                'seller_id',
                'is_active',
                'slug'
            ]);
        });
    }
};
